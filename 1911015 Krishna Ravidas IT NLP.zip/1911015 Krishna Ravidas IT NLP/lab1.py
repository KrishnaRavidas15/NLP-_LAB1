from math import log10
from math import log2

from re import T
from prettytable import PrettyTable
import os


path = os.getcwd()

file1 = open(os.path.join(path, "nlptest1.txt"), mode='r')
file2 = open(os.path.join(path, "nlptest2.txt"), mode='r')
file3 = open(os.path.join(path, "nlptest3.txt"), mode='r')
file4 = open(os.path.join(path, "nlptest4.txt"), mode='r')
file5 = open(os.path.join(path, "nlptest5.txt"), mode='r')

files = [file1, file2, file3, file4, file5]  # list of files
words = []
allUniqueWords = []  # it is the list containing all the unique words from all five files

for file in files:
    w = file.read().lower()  # case folding
    words.append(w.split())  # tokanization


for i in range(len(words)):  # puncuation handling
    words[i] = [word.strip('.,!()[]') for word in words[i]]
    words[i] = [word.replace("'re", '') for word in words[i]]
    words[i] = [word.replace("'s", '') for word in words[i]]

# print(words[1])
# print(words)

for word in words:
    for text in word:
        if text not in allUniqueWords:
            allUniqueWords.append(text)

allUniqueWords.sort()
# print(allUniqueWords)
# print("length: ", len(allUniqueWords))


# lets find the frequencies of words in all five files
frequencies_table = []
for word in words:
    freq = []
    for text in allUniqueWords:
        num = word.count(text)
        freq.append(num)
    frequencies_table.append(freq)

frequencies_table.insert(0, allUniqueWords)
#calculating tf(Term frequency)
for i in range(1,len(words)+1):
    TF=[]
    tnw=len(words[i-1])
    for f in frequencies_table[i]:
        num = int(f)/int(tnw)
        TF.append(round(num,4))
    frequencies_table.append(TF)
# print(frequencies_table)
# print(len(frequencies_table))

#calculating IDF
idf=[]
N = len(files)
for i in range(len(allUniqueWords)):
    idf_res=0
    freq_of_word=0
    length =len(words)+1
    for j in range(1,length):
        if(frequencies_table[j][i]>0):
            freq_of_word+=1
    idf_res = log10(N/freq_of_word)
    idf.append(round(idf_res,4))        

#print(idf)
frequencies_table.append(idf)


#TFID table 

TIDF=[]
for i in range(6,11):
 
    tidf =[]
    for j in range(len(allUniqueWords)):
        num = frequencies_table[i][j]*frequencies_table[11][j]
        tidf.append(round(num,4))
    TIDF.append(tidf)    

# print(TIDF)








#this is final matrix --------
field = ["words", "doc-1", "doc-2", "doc-3", "doc-4", "doc-5","TF_doc-1", "TF_doc-2", "TF_doc-3", "TF_doc-4", "TF_doc-5","IDF"]
matrix = PrettyTable()
for i in range(len(frequencies_table)):
    matrix.add_column(field[i], frequencies_table[i])

print(matrix) #display idf and tf table

field2 = ["TIDF_doc-1","TIDF_doc-2","TIDF_doc-3","TIDF_doc-4","TIDF_doc-5"]
matrix2 =PrettyTable()
for i in range(len(field2)):
    matrix2.add_column(field2[i],TIDF[i])


print(matrix2)# display tidf table





